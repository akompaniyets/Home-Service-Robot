#!/bin/sh
xterm -e "roslaunch my_bot my_world.launch" &
sleep 5
xterm -e "roslaunch gmapping slam_gmapping_pr2.launch" &
sleep 5
xterm -e "rosrun teleop_twist_keyboard teleop_twist_keyboard.py"
