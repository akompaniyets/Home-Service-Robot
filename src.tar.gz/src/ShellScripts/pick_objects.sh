#!/bin/sh
xterm -e "roslaunch my_bot my_world.launch" &
sleep 5
xterm -e "roslaunch my_bot amcl.launch" &
sleep 5
xterm -e "rosrun pick_objects pick_objects"
