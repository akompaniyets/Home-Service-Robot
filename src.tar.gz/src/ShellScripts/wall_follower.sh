#!/bin/sh
xterm -e "roslaunch my_bot my_world.launch" &
sleep 5
xterm -e "roslaunch gmapping slam_gmapping_pr2.launch" &
sleep 5
xterm -e "rosrun wall_follower wall_follower"
