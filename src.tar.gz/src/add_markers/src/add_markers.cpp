#include <ros/ros.h>
#include <visualization_msgs/Marker.h>
#include <std_msgs/String.h>

int counter = 0;


void goal(const std_msgs::StringConstPtr& str){
  if (str->data == "1"){counter = 1;}
  else if (str->data == "2"){counter = 2;}
}

//ros::NodeHandle n;
//ros::Subscriber goals = n.subscribe("checkpoints", 1, goal);

int main( int argc, char** argv )
{
  ros::init(argc, argv, "add_markers");
  ros::NodeHandle n;
  ros::Rate r(1);
  ros::Publisher marker_pub = n.advertise<visualization_msgs::Marker>("visualization_marker", 1);
  ros::Subscriber goals = n.subscribe("checkpoints", 1, goal);

  // Set our initial shape type to be a cube
  uint32_t shape = visualization_msgs::Marker::CUBE;

  //while (ros::ok())
  //{
    visualization_msgs::Marker marker;
    // Set the frame ID and timestamp.  See the TF tutorials for information on these.
    marker.header.frame_id = "map";
    marker.header.stamp = ros::Time::now();

    // Set the namespace and id for this marker.  This serves to create a unique ID
    // Any marker sent with the same namespace and id will overwrite the old one
    marker.ns = "basic_shapes";
    marker.id = 0;

    // Set the marker type.  Initially this is CUBE, and cycles between that and SPHERE, ARROW, and CYLINDER
    marker.type = shape;

    // Set the marker action.  Options are ADD, DELETE, and new in ROS Indigo: 3 (DELETEALL)
    marker.action = visualization_msgs::Marker::ADD;

    // Set the pose of the marker.  This is a full 6DOF pose relative to the frame/time specified in the header
    marker.pose.position.x = 1.0;
    marker.pose.position.y = 0;
    marker.pose.position.z = 0;
    marker.pose.orientation.x = 0.0;
    marker.pose.orientation.y = 0.0;
    marker.pose.orientation.z = 0.0;
    marker.pose.orientation.w = 1.0;

    // Set the scale of the marker -- 1x1x1 here means 1m on a side
    marker.scale.x = 0.2;
    marker.scale.y = 0.2;
    marker.scale.z = 0.2;

    // Set the color -- be sure to set alpha to something non-zero!
    marker.color.r = 0.0f;
    marker.color.g = 1.0f;
    marker.color.b = 0.0f;
    marker.color.a = 1.0;

    marker.lifetime = ros::Duration();
    //marker.lifetime = ros::Duration(5.0);

    // Publish the marker
    while (marker_pub.getNumSubscribers() < 1)
    {
      if (!ros::ok())
      {
        return 0;
      }
      ROS_WARN_ONCE("Please create a subscriber to the marker");
      sleep(1);
    }

    marker_pub.publish(marker);

    std_msgs::StringConstPtr x = ros::topic::waitForMessage<std_msgs::String>("/checkpoints");

    if (x->data == "1"){
	ROS_INFO("Got checkpoint");
	visualization_msgs::Marker marker3;
    
        marker3.header.frame_id = "map";
        marker3.header.stamp = ros::Time::now();

        marker3.ns = "basic_shapes";
        marker3.id = 0;

        // Set the marker type.  Initially this is CUBE, and cycles between that and SPHERE, ARROW, and CYLINDER
        marker3.type = shape;

        // Set the marker action.  Options are ADD, DELETE, and new in ROS Indigo: 3 (DELETEALL)
        marker3.action = visualization_msgs::Marker::ADD;

        // Set the pose of the marker.  This is a full 6DOF pose relative to the frame/time specified in the header
        marker3.pose.position.x = -4.0;
        marker3.pose.position.y = 0;
        marker3.pose.position.z = 0;
        marker3.pose.orientation.x = 0.0;
        marker3.pose.orientation.y = 0.0;
        marker3.pose.orientation.z = 0.0;
        marker3.pose.orientation.w = 1.0;

        // Set the scale of the marker -- 1x1x1 here means 1m on a side
        marker3.scale.x = 0;
        marker3.scale.y = 0;
        marker3.scale.z = 0;

        // Set the color -- be sure to set alpha to something non-zero!
        marker3.color.r = 0.0f;
        marker3.color.g = 1.0f;
        marker3.color.b = 0.0f;
        marker3.color.a = 1.0;

        marker3.lifetime = ros::Duration();

        marker_pub.publish(marker3); 
    }
    //ros::Duration(5.0).sleep();

    std_msgs::StringConstPtr y = ros::topic::waitForMessage<std_msgs::String>("/checkpoints");

    if (y->data == "2"){
      ROS_INFO("Got to goal");
      visualization_msgs::Marker marker2;
    
      marker2.header.frame_id = "map";
      marker2.header.stamp = ros::Time::now();

      marker2.ns = "basic_shapes";
      marker2.id = 0;

      // Set the marker type.  Initially this is CUBE, and cycles between that and SPHERE, ARROW, and CYLINDER
      marker2.type = shape;

      // Set the marker action.  Options are ADD, DELETE, and new in ROS Indigo: 3 (DELETEALL)
      marker2.action = visualization_msgs::Marker::ADD;

      // Set the pose of the marker.  This is a full 6DOF pose relative to the frame/time specified in the header
      marker2.pose.position.x = 4.0;
      marker2.pose.position.y = 5.0;
      marker2.pose.position.z = 0;
      marker2.pose.orientation.x = 0.0;
      marker2.pose.orientation.y = 0.0;
      marker2.pose.orientation.z = 0.0;
      marker2.pose.orientation.w = 1.0;

      // Set the scale of the marker -- 1x1x1 here means 1m on a side
      marker2.scale.x = 0.2;
      marker2.scale.y = 0.2;
      marker2.scale.z = 0.2;

      // Set the color -- be sure to set alpha to something non-zero!
      marker2.color.r = 0.0f;
      marker2.color.g = 1.0f;
      marker2.color.b = 0.0f;
      marker2.color.a = 1.0;

      marker2.lifetime = ros::Duration();

      marker_pub.publish(marker2); 
    }


    // Cycle between different shapes
    //switch (shape)
    //{
    //case visualization_msgs::Marker::CUBE:
      //shape = visualization_msgs::Marker::SPHERE;
      //break;
    //case visualization_msgs::Marker::SPHERE:
      //shape = visualization_msgs::Marker::ARROW;
      //break;
    //case visualization_msgs::Marker::ARROW:
      //shape = visualization_msgs::Marker::CYLINDER;
      //break;
    //case visualization_msgs::Marker::CYLINDER:
      //shape = visualization_msgs::Marker::CUBE;
      //break;
    //}

    //r.sleep();
  //}
  ros::spin();
}
